import { Category, Product, ProductUnit, Vendor, Department, ActivityLog, PurchaseOrder, ReturnItem, StockRequest } from '../types';

export const INITIAL_DEPARTMENTS: Department[] = [
  { id: '1', name: 'Computer Science' },
  { id: '2', name: 'Mechanical Engineering' },
  { id: '3', name: 'Chemical Sciences' },
  { id: '4', name: 'Business Administration' },
  { id: '5', name: 'Electrical Engineering' },
  { id: '6', name: 'Central Library' },
  { id: '7', name: 'Physical Education' },
];

export const INITIAL_LOGS: ActivityLog[] = [
  { id: '1', action: 'Stock Issue', user: 'Admin', timestamp: new Date(Date.now() - 3600000).toISOString(), details: 'Issued 10 Blue Ink Pens to CSE Dept.' },
  { id: '2', action: 'GRN Completed', user: 'Admin', timestamp: new Date(Date.now() - 7200000).toISOString(), details: 'Received 50 packs of A4 Paper from SVS Ltd.' },
  { id: '3', action: 'Stock Alert', user: 'System', timestamp: new Date(Date.now() - 14400000).toISOString(), details: 'A4 Paper Bundle reached critical levels (15 left).' },
  { id: '4', action: 'New Vendor', user: 'Store Manager', timestamp: new Date(Date.now() - 86400000).toISOString(), details: 'Onboarded Global Tech Solutions for lab equipment.' },
  { id: '5', action: 'PO Raised', user: 'Admin', timestamp: new Date(Date.now() - 172800000).toISOString(), details: 'Raised PO-2024-005 for Desktop PCs.' },
];

export const INITIAL_POS: PurchaseOrder[] = [
  { 
    id: '1', 
    poNumber: 'PO-2024-001', 
    vendorId: '1', 
    vendorName: 'Sri Vinayaka Supplies', 
    orderDate: new Date(Date.now() - 86400000 * 10).toISOString(), 
    expectedDeliveryDate: new Date(Date.now() - 86400000 * 5).toISOString(), 
    status: 'Fulfilled', 
    totalAmount: 45000, 
    items: [
      { productId: '1', productName: 'Blue Ink Pen', quantity: 500, unitPrice: 10 },
      { productId: '2', productName: 'A4 Paper Bundle', quantity: 100, unitPrice: 350 },
    ] 
  },
  { 
    id: '2', 
    poNumber: 'PO-2024-002', 
    vendorId: '2', 
    vendorName: 'Global Tech Solutions', 
    orderDate: new Date(Date.now() - 86400000 * 2).toISOString(), 
    expectedDeliveryDate: new Date(Date.now() + 86400000 * 3).toISOString(), 
    status: 'Awaiting Delivery', 
    totalAmount: 120000, 
    items: [
      { productId: '4', productName: 'Dell Monitor 24"', quantity: 10, unitPrice: 12000 },
    ] 
  },
  { 
    id: '3', 
    poNumber: 'PO-2024-003', 
    vendorId: '1', 
    vendorName: 'Sri Vinayaka Supplies', 
    orderDate: new Date().toISOString(), 
    expectedDeliveryDate: new Date(Date.now() + 86400000 * 7).toISOString(), 
    status: 'Ordered', 
    totalAmount: 8500, 
    items: [
      { productId: '5', productName: 'Highlighter Set', quantity: 50, unitPrice: 170 },
    ] 
  },
  { 
    id: '4', 
    poNumber: 'PO-2023-098', 
    vendorId: '3', 
    vendorName: 'Modern Furniture Corp', 
    orderDate: new Date('2023-11-15').toISOString(), 
    expectedDeliveryDate: new Date('2023-11-20').toISOString(), 
    status: 'Fulfilled', 
    totalAmount: 250000, 
    items: [
      { productId: '6', productName: 'Ergonomic Chair', quantity: 25, unitPrice: 10000 },
    ] 
  },
  { 
    id: '5', 
    poNumber: 'PO-2023-105', 
    vendorId: '2', 
    vendorName: 'Global Tech Solutions', 
    orderDate: new Date('2023-12-05').toISOString(), 
    expectedDeliveryDate: new Date('2023-12-10').toISOString(), 
    status: 'Cancelled', 
    totalAmount: 15000, 
    items: [
      { productId: '7', productName: 'Laptop Charger 65W', quantity: 15, unitPrice: 1000 },
    ] 
  },
];

export const INITIAL_RETURNS: ReturnItem[] = [
  { id: '1', type: 'Internal', productId: '1', productName: 'Blue Ink Pen', quantity: 5, date: new Date().toISOString(), reason: 'Defective Nib', status: 'Completed' },
  { id: '2', type: 'Purchase', productId: '4', productName: 'Dell Monitor 24"', quantity: 1, date: new Date(Date.now() - 86400000).toISOString(), reason: 'Dead Pixels', status: 'Initiated' },
  { id: '3', type: 'Internal', productId: '2', productName: 'A4 Paper Bundle', quantity: 2, date: new Date(Date.now() - 172800000).toISOString(), reason: 'Water Damage', status: 'Completed' },
];

export const INITIAL_CATEGORIES: Category[] = [
  { id: '1', name: 'Office Supplies', subCategory: 'Stationery', description: 'General office stationery', createdAt: new Date().toISOString() },
  { id: '2', name: 'Laboratory', subCategory: 'Chemicals', description: 'Chemicals for science labs', createdAt: new Date().toISOString() },
  { id: '3', name: 'Furniture', subCategory: 'Institutional', description: 'Desks, chairs, and cabinets', createdAt: new Date().toISOString() },
  { id: '4', name: 'Computing', subCategory: 'Peripherals', description: 'Monitors, Keyboards, and UPS', createdAt: new Date().toISOString() },
];

export const INITIAL_UNITS: ProductUnit[] = [
  { id: '1', name: 'Numbers', description: 'Countable items', uom: 'Nos' },
  { id: '2', name: 'Box of 12', description: 'Dozen pack', uom: 'Box', mappings: '1 Box -> 12 Nos' },
  { id: '3', name: 'Kilograms', description: 'Weight metric', uom: 'Kg' },
  { id: '4', name: 'Liters', description: 'Volume metric', uom: 'Liters' },
];

export const INITIAL_VENDORS: Vendor[] = [
  { id: '1', name: 'Sri Vinayaka Supplies', companyName: 'SVS Ltd', phone: '9845012345', email: 'sales@svs.com', address: '12-B, Industrial Estate, Chennai', pan: 'ABCDE1234F', bankName: 'SBI', accountNumber: '123456789', ifsc: 'SBIN000123', branch: 'Adyar', gst: '33ABCDE1234F1Z1', aadhaar: '123412341234' },
  { id: '2', name: 'Global Tech Solutions', companyName: 'GTS India', phone: '9000188223', email: 'support@gts.in', address: 'Whitefield Main Road, Bangalore', pan: 'FGHIJ5678K', bankName: 'HDFC', accountNumber: '987654321', ifsc: 'HDFC000456', branch: 'ITPL', gst: '29FGHIJ5678K1Z2', aadhaar: '567856785678' },
  { id: '3', name: 'Modern Furniture Corp', companyName: 'MFC Ltd', phone: '7878787878', email: 'orders@mfc.com', address: 'Sector 5, Noida, UP', pan: 'LMNOP9012Q', bankName: 'ICICI', accountNumber: '456123789', ifsc: 'ICIC000789', branch: 'Noida Hub', gst: '09LMNOP9012Q1Z3', aadhaar: '901290129012' },
];

export const INITIAL_PRODUCTS: Product[] = [
  { id: '1', name: 'Blue Ink Pen', categoryId: '1', unitId: '1', minLevel: 100, currentStock: 250, price: 10 },
  { id: '2', name: 'A4 Paper Bundle', categoryId: '1', unitId: '2', minLevel: 20, currentStock: 15, price: 350 },
  { id: '3', name: 'HCL Solution 1L', categoryId: '2', unitId: '4', minLevel: 5, currentStock: 12, price: 120 },
  { id: '4', name: 'Dell Monitor 24"', categoryId: '4', unitId: '1', minLevel: 2, currentStock: 8, price: 12000 },
  { id: '5', name: 'Highlighter Set', categoryId: '1', unitId: '1', minLevel: 10, currentStock: 45, price: 170 },
  { id: '6', name: 'Ergonomic Chair', categoryId: '3', unitId: '1', minLevel: 5, currentStock: 30, price: 10000 },
  { id: '7', name: 'Laptop Charger 65W', categoryId: '4', unitId: '1', minLevel: 3, currentStock: 4, price: 1000 },
];

export const INITIAL_REQUESTS: StockRequest[] = [
  {
    id: '1',
    requestNumber: 'REQ-2024-001',
    productId: '1',
    productName: 'Blue Ink Pen',
    requestedQty: 50,
    priority: 'Low',
    reason: 'Standard office replenishment',
    requesterName: 'Dr. Ramesh Kumar',
    departmentId: '1',
    departmentName: 'Computer Science',
    requestedDate: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'Approved',
    approvalChain: []
  },
  {
    id: '2',
    requestNumber: 'REQ-2024-002',
    productId: '4',
    productName: 'Dell Monitor 24"',
    requestedQty: 2,
    priority: 'High',
    reason: 'Critical replacement for main lab server',
    requesterName: 'Prof. Sarah John',
    departmentId: '1',
    departmentName: 'Computer Science',
    requestedDate: new Date().toISOString(),
    status: 'Pending',
    approvalChain: []
  },
  {
    id: '3',
    requestNumber: 'REQ-2024-003',
    productId: '3',
    productName: 'HCL Solution 1L',
    requestedQty: 5,
    priority: 'Medium',
    reason: 'Upcoming practical examinations',
    requesterName: 'Mr. Anil Kapur',
    departmentId: '3',
    departmentName: 'Chemical Sciences',
    requestedDate: new Date().toISOString(),
    status: 'Pending',
    approvalChain: []
  }
];
