import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import { UserRole, Category, ProductUnit, Vendor, Product, GRN, StockRequest, ActivityLog, Department, PurchaseOrder, ReturnItem } from './types';
import { INITIAL_CATEGORIES, INITIAL_UNITS, INITIAL_VENDORS, INITIAL_PRODUCTS, INITIAL_DEPARTMENTS, INITIAL_LOGS, INITIAL_POS, INITIAL_RETURNS, INITIAL_REQUESTS } from './lib/constants';

// Page Imports
import StoreOps360 from './pages/StoreOps360';
import StoreInventory from './pages/StoreInventory';
import Procurement from './pages/Procurement';
import Reporting from './pages/Reporting';

export default function App() {
  // Global State
  const [role, setRole] = useState<UserRole>('Admin');
  const [activeTab, setActiveTab] = useState('360');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Persistence (Mock)
  const [categories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [units] = useState<ProductUnit[]>(INITIAL_UNITS);
  const [vendors, setVendors] = useState<Vendor[]>(INITIAL_VENDORS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [departments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [requests, setRequests] = useState<StockRequest[]>(INITIAL_REQUESTS);
  const [grns, setGrns] = useState<GRN[]>([]);
  const [pos, setPos] = useState<PurchaseOrder[]>(INITIAL_POS);
  const [returns, setReturns] = useState<ReturnItem[]>(INITIAL_RETURNS);
  const [logs, setLogs] = useState<ActivityLog[]>(INITIAL_LOGS);

  const addLog = (action: string, details: string) => {
    const newLog: ActivityLog = {
      id: Math.random().toString(36).substr(2, 9),
      action,
      user: role,
      timestamp: new Date().toISOString(),
      details
    };
    setLogs(prev => [newLog, ...prev]);
  };

  // Page Content Switcher
  const renderContent = () => {
    switch (activeTab) {
      case '360':
        return <StoreOps360 products={products} requests={requests} returns={returns} pos={pos} onTileClick={setActiveTab} logs={logs} />;
      case 'inventory':
        return (
          <StoreInventory 
            products={products} setProducts={setProducts} 
            requests={requests} setRequests={setRequests} 
            returns={returns} setReturns={setReturns}
            departments={departments}
            role={role}
            addLog={addLog}
          />
        );
      case 'procurement':
        return (
          <Procurement 
            vendors={vendors} setVendors={setVendors}
            pos={pos} setPos={setPos}
            grns={grns} setGrns={setGrns}
            products={products}
            role={role}
            addLog={addLog}
          />
        );
      case 'dashboard':
        return <Reporting products={products} requests={requests} grns={grns} pos={pos} returns={returns} />;
      default:
        return <StoreOps360 products={products} requests={requests} returns={returns} pos={pos} onTileClick={setActiveTab} logs={logs} />;
    }
  };

  return (
    <div className="min-h-screen bg-bg flex">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        role={role} 
        isOpen={sidebarOpen} 
        setIsOpen={setSidebarOpen} 
      />
      
      <main className="flex-1 lg:ml-70 flex flex-col min-h-screen transition-all duration-300">
        <Header 
          onMenuClick={() => setSidebarOpen(true)} 
          role={role} 
          setRole={setRole} 
        />
        
        <div className="p-10 flex-1">
          <div className="max-w-[1400px] mx-auto">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
}

