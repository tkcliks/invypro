import React, { useState } from 'react';
import { Plus, Search, FileText, CheckCircle, XCircle, Clock, MoreVertical, Send, UserCheck, ShieldCheck, AlertTriangle, ArrowRight, ChevronRight, CheckCircle2 } from 'lucide-react';
import { StockRequest, Product, UserRole } from '../types';

interface RequestsPageProps {
  requests: StockRequest[];
  setRequests: React.Dispatch<React.SetStateAction<StockRequest[]>>;
  products: Product[];
  role: UserRole;
}

export default function RequestsPage({ requests, setRequests, products, role }: RequestsPageProps) {
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // New Request Form
  const [newRequest, setNewRequest] = useState<Partial<StockRequest>>({
    productId: '',
    requestedQty: 0,
    priority: 'Medium',
    reason: ''
  });

  const handleCreateRequest = () => {
    const product = products.find(p => p.id === newRequest.productId);
    const req: StockRequest = {
      id: Math.random().toString(),
      requestNumber: `REQ-${Math.floor(Math.random() * 9000) + 1000}`,
      productId: newRequest.productId!,
      productName: product?.name || '',
      requestedQty: newRequest.requestedQty!,
      priority: newRequest.priority as any,
      reason: newRequest.reason!,
      requesterName: 'Staff Member',
      departmentId: '1',
      departmentName: 'General',
      requestedDate: new Date().toISOString(),
      status: 'Pending',
      approvalChain: []
    };

    setRequests(prev => [req, ...prev]);
    setShowRequestModal(false);
    setNewRequest({ priority: 'Medium' });
  };

  const handleApprove = (id: string, action: 'Approve' | 'Reject') => {
    setRequests(prev => prev.map(r => 
      r.id === id ? { ...r, status: action === 'Approve' ? 'Approved' : 'Rejected' } : r
    ));
  };

  const filteredRequests = requests.filter(r => {
    if (activeTab === 'pending') return r.status === 'Pending';
    if (activeTab === 'approved') return r.status === 'Approved' || r.status.includes('Issued');
    return true;
  }).filter(r => r.productName.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Indent Requests</h1>
          <p className="text-slate-500 text-sm mt-1">Manage departmental stock requisitions and approvals</p>
        </div>
        <button 
          onClick={() => setShowRequestModal(true)}
          className="btn-primary"
        >
          <Send size={18} />
          Raise New Indent
        </button>
      </div>

      <div className="flex border-b border-slate-200">
        {[
          { id: 'all', label: 'All Requests' },
          { id: 'pending', label: 'Pending Approval' },
          { id: 'approved', label: 'Issued / Approved' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-6 py-3 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${
              activeTab === tab.id 
              ? 'border-primary text-primary' 
              : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="glass-card">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50/30">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" 
              placeholder="Search indents..."
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto min-h-[400px]">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Indent No / Date</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Requested Item</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Quantity</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Priority</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRequests.map((req) => (
                <tr key={req.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <p className="text-sm font-bold text-slate-900">{req.requestNumber}</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase">{new Date(req.requestedDate).toLocaleDateString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-semibold text-slate-700">{req.productName}</p>
                    <p className="text-[10px] text-slate-400 truncate max-w-[150px]">{req.reason}</p>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-900">{req.requestedQty}</td>
                  <td className="px-6 py-4">
                    <span className={`flex items-center gap-1.5 text-[9px] font-bold uppercase ${
                      req.priority === 'High' ? 'text-red-600' :
                      req.priority === 'Medium' ? 'text-amber-600' : 'text-slate-500'
                    }`}>
                      {req.priority === 'High' && <AlertTriangle size={12} />}
                      {req.priority}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase flex items-center gap-1 w-fit ${
                      req.status === 'Pending' ? 'bg-amber-100 text-amber-700' :
                      req.status === 'Approved' ? 'bg-blue-100 text-blue-700' :
                      req.status === 'Rejected' ? 'bg-red-100 text-red-700' :
                      'bg-emerald-100 text-emerald-700'
                    }`}>
                      {req.status === 'Pending' ? <Clock size={10} /> : <CheckCircle2 size={10} />}
                      {req.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    {role === 'Admin' && req.status === 'Pending' ? (
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => handleApprove(req.id, 'Approve')}
                          className="p-1.5 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 rounded-lg transition-colors"
                        >
                          <UserCheck size={16} />
                        </button>
                        <button 
                          onClick={() => handleApprove(req.id, 'Reject')}
                          className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg transition-colors"
                        >
                          <XCircle size={16} />
                        </button>
                      </div>
                    ) : (
                      <button className="text-slate-400 hover:text-slate-600">
                        <MoreVertical size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {filteredRequests.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center gap-2">
                      <div className="bg-slate-100 p-4 rounded-full text-slate-300">
                        <FileText size={32} />
                      </div>
                      <p className="text-slate-400 text-sm font-medium">No indent requests found matching your filter.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0">
              <h3 className="text-xl font-bold text-slate-900 tracking-tight uppercase">Raise New Stock Indent</h3>
              <button onClick={() => setShowRequestModal(false)} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400">
                <XCircle size={20} />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <div className="bg-primary/5 p-4 rounded-xl border border-primary/10 flex gap-4 mb-4">
                <div className="bg-primary p-2 h-fit rounded-lg text-white">
                  <ShieldCheck size={20} />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-primary tracking-tight">Standard Institutional Workflow</h4>
                  <p className="text-[10px] text-primary/70 font-bold uppercase leading-tight mt-0.5">Your request will be routed to HOD and then Central Store for verification.</p>
                </div>
              </div>

              <div>
                <label className="input-label">Item Required</label>
                <select 
                  className="form-input"
                  onChange={e => setNewRequest({...newRequest, productId: e.target.value})}
                >
                  <option value="">Select an item...</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.name} (Stock: {p.currentStock})</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Quantity</label>
                  <input 
                    type="number" className="form-input" placeholder="0"
                    onChange={e => setNewRequest({...newRequest, requestedQty: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="input-label">Priority</label>
                  <select 
                    className="form-input"
                    onChange={e => setNewRequest({...newRequest, priority: e.target.value as any})}
                  >
                    <option value="Low">Low Priority</option>
                    <option value="Medium">Medium Priority</option>
                    <option value="High">High / Emergency</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="input-label">Reason / Justification</label>
                <textarea 
                  className="form-input h-24" placeholder="Briefly explain the need for this stock..."
                  onChange={e => setNewRequest({...newRequest, reason: e.target.value})}
                ></textarea>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-3">
              <button onClick={() => setShowRequestModal(false)} className="btn-ghost">Cancel</button>
              <button 
                onClick={handleCreateRequest}
                className="btn-primary"
                disabled={!newRequest.productId || !newRequest.requestedQty}
              >
                Submit Indent
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
