import React from 'react';
import { Package, ClipboardList, TrendingUp, AlertTriangle, ArrowUpRight, ArrowDownRight, Clock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { Product, StockRequest, GRN } from '../types';

interface DashboardProps {
  products: Product[];
  requests: StockRequest[];
  grns: GRN[];
}

export default function DashboardPage({ products, requests, grns }: DashboardProps) {
  // Stats calculations
  const totalStockValue = products.reduce((acc, p) => acc + (p.currentStock * p.price), 0);
  const pendingRequests = requests.filter(r => r.status === 'Pending').length;
  const criticalItems = products.filter(p => p.currentStock <= p.minLevel).length;

  const stockData = products.slice(0, 5).map(p => ({
    name: p.name,
    stock: p.currentStock,
    min: p.minLevel
  }));

  const requestStatusData = [
    { name: 'Pending', value: requests.filter(r => r.status === 'Pending').length, color: '#F59E0B' },
    { name: 'Approved', value: requests.filter(r => r.status === 'Approved').length, color: '#0052CC' },
    { name: 'Issued', value: requests.filter(r => r.status === 'Fully Issued').length, color: '#36B37E' },
    { name: 'Rejected', value: requests.filter(r => r.status === 'Rejected').length, color: '#EF4444' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="hero-banner relative overflow-hidden">
        <div className="relative z-10">
          <h1 className="text-3xl font-extrabold mb-2">Welcome back, SRM Admin.</h1>
          <p className="text-white/80 max-w-lg text-sm leading-relaxed">
            Your inventory availability increased by 12% this week. We've flagged {criticalItems} critical items that require your immediate attention to ensure uninterrupted college operations.
          </p>
        </div>
        <div className="absolute right-[-10%] top-[-20%] w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute right-[5%] bottom-[-10%] w-48 h-48 bg-accent/20 rounded-full blur-2xl"></div>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-text-main flex items-center gap-2">
            System Pulse <span className="status-pill">Live Monitoring</span>
          </h2>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black text-text-sub bg-surface px-3 py-1.5 rounded-md border border-border shadow-sm">
          <Clock size={12} />
          REFRESHED {new Date().toLocaleTimeString()}
        </div>
      </div>

      {/* Summary Tiles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Stock Items', value: products.length, icon: Package, color: 'text-primary', bg: 'bg-primary/5', trend: '▲ 2.4% vs avg.' },
          { label: 'Total Valuation', value: `₹${totalStockValue.toLocaleString()}`, icon: TrendingUp, color: 'text-success', bg: 'bg-success/5', trend: 'Market growth' },
          { label: 'Pending Indents', value: pendingRequests, icon: ClipboardList, color: 'text-amber-600', bg: 'bg-amber-50', trend: 'Awaiting Action' },
          { label: 'Low Stock Alerts', value: criticalItems, icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50', trend: 'Action Required' },
        ].map((stat, idx) => (
          <div key={idx} className="glass-card p-6 flex flex-col justify-between group hover:border-primary transition-all duration-300">
            <div className="flex items-center justify-between mb-4">
              <div className={stat.bg + " p-2.5 rounded-lg text-white"}>
                <stat.icon className={stat.color} size={20} />
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${stat.trend.includes('▲') ? 'text-success bg-success/10' : 'text-text-sub bg-bg'}`}>
                {stat.trend}
              </span>
            </div>
            <div>
              <p className="stat-label">{stat.label}</p>
              <h3 className="stat-value">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card p-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-bold text-text-main text-base uppercase tracking-wider">Stock Health Distribution</h2>
            <div className="flex items-center gap-4 text-[10px] font-bold uppercase text-text-sub">
              <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-primary"></span> Current Stock</div>
              <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-border"></span> Minimum Level</div>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stockData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#DFE1E6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#5E6C84', fontWeight: 600 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#5E6C84', fontWeight: 600 }} />
                <Tooltip 
                  cursor={{ fill: '#F4F5F7' }}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #DFE1E6', boxShadow: '0 4px 12px rgba(0,0,0,0.05)', fontSize: '12px' }}
                />
                <Bar dataKey="stock" fill="#0052CC" radius={[2, 2, 0, 0]} barSize={32} />
                <Bar dataKey="min" fill="#DFE1E6" radius={[2, 2, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-8 flex flex-col">
          <h2 className="font-bold text-text-main text-base uppercase tracking-wider mb-8">Request Lifecycle</h2>
          <div className="flex-1 flex items-center justify-center">
            {requestStatusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={requestStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={95}
                    paddingAngle={2}
                    dataKey="value"
                    stroke="none"
                  >
                    {requestStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-10 opacity-50">
                <Package size={48} className="mx-auto text-border mb-4" />
                <p className="text-text-sub text-xs uppercase font-bold">No active requests</p>
              </div>
            )}
          </div>
          <div className="space-y-3 mt-6">
            {requestStatusData.map((status, i) => (
              <div key={i} className="flex items-center justify-between border-b border-border/50 pb-2">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: status.color }}></div>
                  <span className="text-[11px] font-bold text-text-sub uppercase tracking-wider">{status.name}</span>
                </div>
                <span className="text-sm font-bold text-text-main">{status.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
