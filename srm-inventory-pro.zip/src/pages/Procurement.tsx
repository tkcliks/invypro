import React, { useState } from 'react';
import { Truck, FileText, Users, Search, Plus, Download, Edit2, Trash2, ChevronRight, BarChart2, IndianRupee, History } from 'lucide-react';
import { PurchaseOrder, Vendor, GRN, UserRole, Product } from '../types';
import OrderHistory from './OrderHistory';

interface ProcurementProps {
  vendors: Vendor[];
  setVendors: React.Dispatch<React.SetStateAction<Vendor[]>>;
  pos: PurchaseOrder[];
  setPos: React.Dispatch<React.SetStateAction<PurchaseOrder[]>>;
  grns: GRN[];
  setGrns: React.Dispatch<React.SetStateAction<GRN[]>>;
  products: Product[];
  role: UserRole;
  addLog: (action: string, details: string) => void;
}

export default function Procurement({ 
  vendors, setVendors, 
  pos, setPos, 
  grns, setGrns, 
  products,
  role,
  addLog 
}: ProcurementProps) {
  const [activeSubTab, setActiveSubTab] = useState('pos');
  const [searchQuery, setSearchQuery] = useState('');
  const [showVendorModal, setShowVendorModal] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);

  const activePOs = pos.filter(po => 
    po.status !== 'Fulfilled' && po.status !== 'Cancelled'
  );

  const handleSaveVendor = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const vendorData = Object.fromEntries(formData.entries()) as any;

    if (editingVendor) {
      setVendors(prev => prev.map(v => v.id === editingVendor.id ? { ...v, ...vendorData } : v));
      addLog('Vendor Updated', `Vendor ${vendorData.name} details modified.`);
    } else {
      const newVendor: Vendor = {
        id: Math.random().toString(36).substr(2, 9),
        ...vendorData
      };
      setVendors(prev => [...prev, newVendor]);
      addLog('New Vendor Added', `New vendor partner ${vendorData.name} registered.`);
    }
    setShowVendorModal(false);
    setEditingVendor(null);
  };

  const renderPOs = () => (
    <div className="glass-card">
      <div className="p-4 border-b border-border flex items-center justify-between bg-bg/50">
        <h2 className="text-sm font-bold text-text-main uppercase tracking-widest">Active Orders</h2>
        <div className="flex gap-2">
          <button className="btn-primary text-xs py-2 px-4 shadow-none"><Plus size={14} className="mr-2" /> New Order</button>
        </div>
      </div>
      <div className="overflow-x-auto min-h-[400px]">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Order ID</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Vendor</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Valuation</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {activePOs.map((po) => (
              <tr key={po.id} className="hover:bg-bg/10 transition-colors">
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-primary">{po.poNumber}</p>
                  <p className="text-[10px] text-text-sub font-bold">{new Date(po.orderDate).toLocaleDateString()}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-text-main">{po.vendorName}</p>
                  <p className="text-[10px] text-text-sub">{po.items.length} Type of Items</p>
                </td>
                <td className="px-6 py-4">
                  <span className={`status-pill ${
                    po.status === 'Ordered' ? 'bg-blue-50 text-blue-700' :
                    po.status === 'Awaiting Delivery' ? 'bg-amber-50 text-amber-700' :
                    'bg-green-50 text-green-700'
                  }`}>
                    {po.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <p className="text-sm font-black text-text-main">₹{po.totalAmount.toLocaleString()}</p>
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => setSelectedPO(po)}
                    className="p-2 hover:bg-bg rounded border border-transparent hover:border-border text-primary"
                  >
                    <FileText size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderVendors = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {vendors.map((vendor) => (
        <div key={vendor.id} className="glass-card p-6 flex flex-col justify-between group hover:border-primary transition-all duration-300">
          <div>
            <div className="flex items-center justify-between mb-6">
              <div className="w-12 h-12 rounded-lg bg-bg border border-border flex items-center justify-center text-primary text-xl font-black">
                {vendor.name[0]}
              </div>
              <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => { setEditingVendor(vendor); setShowVendorModal(true); }}
                  className="p-1.5 hover:bg-bg rounded border border-border text-text-sub hover:text-primary transition-colors"
                >
                  <Edit2 size={12} />
                </button>
                <button className="p-1.5 hover:bg-bg rounded border border-border text-text-sub hover:text-red-500 transition-colors">
                  <Trash2 size={12} />
                </button>
              </div>
            </div>
            <h3 className="text-lg font-bold text-text-main leading-tight mb-1">{vendor.name}</h3>
            <p className="text-[10px] text-text-sub font-bold uppercase tracking-widest">{vendor.companyName}</p>
            
            <div className="mt-6 space-y-3">
              <div className="flex items-center justify-between border-b border-border pb-2">
                <span className="text-[10px] font-bold text-text-sub uppercase">GST REG.</span>
                <span className="text-[10px] font-mono font-bold text-text-main">{vendor.gst}</span>
              </div>
              <div className="flex items-center justify-between border-b border-border pb-2">
                <span className="text-[10px] font-bold text-text-sub uppercase">Contact</span>
                <span className="text-[10px] font-bold text-text-main">{vendor.phone}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-text-sub uppercase">Bank Account</span>
                <span className="text-[10px] font-bold text-text-main">{vendor.accountNumber}</span>
              </div>
            </div>
          </div>
          <button className="mt-8 btn-ghost w-full text-[10px] font-black uppercase tracking-widest py-3 hover:bg-primary hover:text-white border-primary/20">
            View Analytics Detail
          </button>
        </div>
      ))}
      <button 
        onClick={() => { setEditingVendor(null); setShowVendorModal(true); }}
        className="glass-card border-dashed border-2 border-border p-6 flex flex-col items-center justify-center text-text-sub hover:border-primary hover:text-primary transition-all group"
      >
        <Plus size={32} className="mb-2 group-hover:scale-110 transition-transform" />
        <span className="text-xs font-bold uppercase tracking-wider">New Vendor Onboarding</span>
      </button>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-[1400px] mx-auto p-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-text-main tracking-tight">Procurement & Vendors</h1>
          <p className="text-text-sub text-sm mt-1">Acquisition management, vendor profiles, and delivery verification.</p>
        </div>
      </div>

      <div className="flex border-b border-border">
        {[
          { id: 'pos', label: 'Active Orders', icon: FileText, count: activePOs.length },
          { id: 'history', label: 'Order History', icon: History, count: pos.filter(p => p.status === 'Fulfilled' || p.status === 'Cancelled').length },
          { id: 'vendors', label: 'Vendor Registry', icon: Users, count: vendors.length },
          { id: 'grn', label: 'GRN Logs', icon: Truck, count: grns.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`px-8 py-3 text-[11px] font-bold uppercase tracking-widest transition-all border-b-2 flex items-center gap-2 ${
              activeSubTab === tab.id 
              ? 'border-primary text-primary' 
              : 'border-transparent text-text-sub hover:text-text-main'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
            <span className={`px-2 py-0.5 rounded text-[10px] ${
              activeSubTab === tab.id ? 'bg-primary/10 text-primary' : 'bg-bg text-text-sub'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      <div className="min-h-[500px]">
        {activeSubTab === 'pos' && renderPOs()}
        {activeSubTab === 'history' && <OrderHistory pos={pos} vendors={vendors} products={products} isNested={true} />}
        {activeSubTab === 'vendors' && renderVendors()}
        {activeSubTab === 'grn' && (
          <div className="glass-card overflow-hidden">
            <div className="p-4 border-b border-border bg-bg/50 flex items-center justify-between">
              <h2 className="text-sm font-bold text-text-main uppercase">Verification logs</h2>
              <button className="btn-ghost text-xs px-4 py-1.5 border border-border bg-surface">Export CSV</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-bg border-b border-border">
                    <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">GRN #</th>
                    <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Source Vendor</th>
                    <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Ref Invoices</th>
                    <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {grns.map(grn => (
                    <tr key={grn.id} className="hover:bg-bg/10 transition-colors">
                      <td className="px-6 py-4">
                        <p className="text-sm font-bold text-text-main">{grn.grnNumber}</p>
                        <p className="text-[10px] text-text-sub font-bold">{new Date(grn.date).toLocaleDateString()}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm font-bold text-text-main">{grn.vendorName}</p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-[10px] font-bold text-text-sub">INV: {grn.invoiceNumber}</p>
                        <p className="text-[10px] font-bold text-text-sub">PO: {grn.poReference}</p>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button className="p-2 hover:bg-bg rounded border border-transparent hover:border-border"><Download size={14} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Purchase Order Details Modal */}
      {selectedPO && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in zoom-in duration-200">
          <div className="bg-surface rounded-xl w-full max-w-4xl shadow-2xl border border-border overflow-hidden">
            <div className="p-6 border-b border-border bg-bg/20 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-text-main tracking-tight uppercase">Order Detail: {selectedPO.poNumber}</h3>
                <p className="text-[10px] text-text-sub font-bold uppercase tracking-widest mt-1">Status: <span className="text-primary">{selectedPO.status}</span> • Initiated {new Date(selectedPO.orderDate).toLocaleDateString()}</p>
              </div>
              <button 
                onClick={() => setSelectedPO(null)}
                className="btn-ghost p-2 hover:bg-bg rounded-lg border-border"
              >
                <Plus className="rotate-45" size={24} />
              </button>
            </div>
            
            <div className="p-10 grid grid-cols-3 gap-10 border-b border-border bg-white">
              <div>
                <label className="text-[10px] font-black text-text-sub uppercase tracking-widest block mb-2">Primary Vendor</label>
                <p className="text-base font-bold text-text-main">{selectedPO.vendorName}</p>
                <p className="text-xs text-text-sub mt-1">Assigned Partner ID: {selectedPO.vendorId}</p>
              </div>
              <div>
                <label className="text-[10px] font-black text-text-sub uppercase tracking-widest block mb-2">Committed Value</label>
                <p className="text-2xl font-black text-primary tabular-nums">₹{selectedPO.totalAmount.toLocaleString()}</p>
                <p className="text-[10px] text-text-sub font-bold italic mt-1">Inclusive of estimated institutional discounts</p>
              </div>
              <div>
                <label className="text-[10px] font-black text-text-sub uppercase tracking-widest block mb-2">Timeline Audit</label>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-text-sub uppercase">Ordered</span>
                    <span className="text-[10px] font-bold text-text-main">{new Date(selectedPO.orderDate).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-text-sub uppercase">Expected Receipt</span>
                    <span className="text-[10px] font-bold text-text-main">{new Date(selectedPO.expectedDeliveryDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-0 overflow-auto max-h-[400px]">
              <table className="w-full text-left">
                <thead className="sticky top-0 bg-bg z-10 border-b border-border">
                  <tr>
                    <th className="px-10 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Product Description</th>
                    <th className="px-10 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-center">Qty</th>
                    <th className="px-10 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Unit Net</th>
                    <th className="px-10 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Ext. Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50 bg-white">
                  {selectedPO.items.map((item, id) => (
                    <tr key={id} className="hover:bg-primary/5 transition-colors">
                      <td className="px-10 py-5">
                        <p className="text-sm font-bold text-text-main">{item.productName}</p>
                        <p className="text-[10px] text-text-sub font-mono uppercase tracking-widest">SKU: {item.productId}</p>
                      </td>
                      <td className="px-10 py-5 text-sm font-black text-text-main text-center tabular-nums">{item.quantity}</td>
                      <td className="px-10 py-5 text-sm font-bold text-text-sub text-right tabular-nums">₹{item.unitPrice.toLocaleString()}</td>
                      <td className="px-10 py-5 text-base font-black text-text-main text-right tabular-nums">₹{(item.quantity * item.unitPrice).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-8 bg-bg/20 border-t border-border flex justify-between items-center">
              <div className="flex gap-4">
                <button className="btn-ghost flex items-center gap-2 border border-border px-6 h-11 text-[10px] font-bold uppercase"><FileText size={16} /> Print Voucher</button>
                <button className="btn-ghost flex items-center gap-2 border border-border px-6 h-11 text-[10px] font-bold uppercase"><Download size={16} /> Export PDF</button>
              </div>
              <button 
                onClick={() => setSelectedPO(null)}
                className="btn-primary px-12 h-11 text-[11px] font-black uppercase tracking-widest"
              >
                Close Record View
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Vendor Modal */}
      {showVendorModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in zoom-in duration-200">
          <div className="bg-surface rounded-xl w-full max-w-2xl shadow-2xl border border-border">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-bold text-text-main uppercase tracking-widest">{editingVendor ? 'Edit Vendor Profile' : 'New Vendor Registration'}</h3>
              <button 
                onClick={() => { setShowVendorModal(false); setEditingVendor(null); }}
                className="text-text-sub hover:text-text-main"
              >
                <Plus className="rotate-45" size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveVendor}>
              <div className="p-8 grid grid-cols-2 gap-6 max-h-[70vh] overflow-y-auto">
                <div className="col-span-2">
                  <label className="input-label">Vendor Display Name</label>
                  <input name="name" defaultValue={editingVendor?.name} className="form-input h-10" required />
                </div>
                <div className="col-span-2">
                  <label className="input-label">Registered Company Name</label>
                  <input name="companyName" defaultValue={editingVendor?.companyName} className="form-input h-10" required />
                </div>
                <div>
                  <label className="input-label">GST Number</label>
                  <input name="gst" defaultValue={editingVendor?.gst} className="form-input h-10 uppercase" placeholder="33AAAAA0000A1Z1" />
                </div>
                <div>
                  <label className="input-label">PAN Number</label>
                  <input name="pan" defaultValue={editingVendor?.pan} className="form-input h-10 uppercase" />
                </div>
                <div>
                  <label className="input-label">Email Context</label>
                  <input name="email" type="email" defaultValue={editingVendor?.email} className="form-input h-10" />
                </div>
                <div>
                  <label className="input-label">Contact Phone</label>
                  <input name="phone" defaultValue={editingVendor?.phone} className="form-input h-10" />
                </div>
                <div className="col-span-2 border-t border-border pt-4">
                  <h4 className="text-[10px] font-black text-text-sub uppercase tracking-widest mb-4">Banking & Settlement</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <label className="input-label">Bank Name</label>
                      <input name="bankName" defaultValue={editingVendor?.bankName} className="form-input h-10" />
                    </div>
                    <div>
                      <label className="input-label">Account Number</label>
                      <input name="accountNumber" defaultValue={editingVendor?.accountNumber} className="form-input h-10" />
                    </div>
                    <div>
                      <label className="input-label">IFSC Code</label>
                      <input name="ifsc" defaultValue={editingVendor?.ifsc} className="form-input h-10 uppercase" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 border-t border-border bg-bg/20 flex gap-3 justify-end">
                <button type="button" onClick={() => setShowVendorModal(false)} className="btn-ghost px-6">Discard</button>
                <button type="submit" className="btn-primary px-8">{editingVendor ? 'Save Changes' : 'Confirm Registration'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
