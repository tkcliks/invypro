import React, { useState } from 'react';
import { BarChart2, PieChart as PieChartIcon, FileText, Download, Calendar, Filter, Printer } from 'lucide-react';
import { Product, StockRequest, GRN, PurchaseOrder, ReturnItem } from '../types';

interface ReportingProps {
  products: Product[];
  requests: StockRequest[];
  grns: GRN[];
  pos: PurchaseOrder[];
  returns: ReturnItem[];
}

export default function Reporting({ products, requests, grns, pos, returns }: ReportingProps) {
  const [reportType, setReportType] = useState('audit');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  const reportOptions = [
    { id: 'audit', label: 'Stock Ledger Audit', icon: BarChart2, description: 'Complete movement history of every SKU in the central store.' },
    { id: 'grn', label: 'GRN Summary Report', icon: FileText, description: 'Vendor-wise receipt logs with tax and valuation breakdowns.' },
    { id: 'consumption', label: 'Dept. Consumption', icon: PieChartIcon, description: 'Identify high-usage departments and asset allocation trends.' },
    { id: 'physical', label: 'Physical Verification', icon: Printer, description: 'Standardized sheets for manual warehouse audits and reconciliations.' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-[1400px] mx-auto p-10">
      <div>
        <h1 className="text-3xl font-extrabold text-text-main tracking-tight uppercase">StoreOps Dashboard</h1>
        <p className="text-text-sub text-sm mt-1">Strategic performance indicators and institutional reporting suite.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="glass-card p-8">
            <h2 className="font-bold text-text-main text-base uppercase tracking-wider mb-6">Report Parameters</h2>
            <div className="space-y-4">
              <div>
                <label className="input-label">Select Report Type</label>
                <div className="space-y-2 mt-2">
                  {reportOptions.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setReportType(opt.id)}
                      className={`w-full text-left p-4 rounded-lg border transition-all flex items-start gap-4 ${
                        reportType === opt.id 
                        ? 'bg-primary/5 border-primary ring-1 ring-primary/20' 
                        : 'bg-surface border-border hover:bg-bg/50'
                      }`}
                    >
                      <opt.icon size={18} className={reportType === opt.id ? 'text-primary' : 'text-text-sub'} />
                      <div>
                        <p className={`text-xs font-bold uppercase tracking-wide h-4 mb-1 ${reportType === opt.id ? 'text-primary' : 'text-text-main'}`}>{opt.label}</p>
                        <p className="text-[10px] text-text-sub leading-relaxed">{opt.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="input-label">Date Range</label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-text-sub" size={12} />
                    <input type="date" className="form-input text-[10px] pl-9 h-10" />
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-text-sub" size={12} />
                    <input type="date" className="form-input text-[10px] pl-9 h-10" />
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button className="btn-primary w-full py-3 h-12 flex items-center justify-center gap-3">
                  <Printer size={16} />
                  Generate Audit Report
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 glass-card overflow-hidden h-full flex flex-col">
          <div className="p-6 border-b border-border flex items-center justify-between">
            <div>
              <h2 className="font-bold text-text-main text-base uppercase tracking-wider">Report Preview</h2>
              <p className="text-[10px] text-text-sub font-bold uppercase mt-1">Live preview based on current parameters</p>
            </div>
            <div className="flex gap-2">
              <button className="btn-ghost text-xs px-4 h-9 border border-border bg-surface"><Filter size={14} className="mr-2" /> Adjust View</button>
              <button className="btn-ghost text-xs px-4 h-9 border border-border bg-surface"><Download size={14} className="mr-2" /> PDF</button>
            </div>
          </div>
          <div className="flex-1 flex flex-col items-center justify-center p-20 text-center bg-bg/10">
            <div className="w-20 h-20 rounded-full bg-border/20 flex items-center justify-center text-border mb-6">
              <FileText size={40} />
            </div>
            <h3 className="text-xl font-bold text-text-main mb-2 tracking-tight">System Ready to Compile</h3>
            <p className="text-text-sub text-sm max-w-sm leading-relaxed">
              Verify your date range and report classification on the left to generate the audit-ready ledger.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
