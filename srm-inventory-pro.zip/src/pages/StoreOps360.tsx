import React from 'react';
import { Package, ClipboardList, Truck, AlertTriangle, TrendingUp, TrendingDown, ArrowRight, Clock, ShoppingCart, RotateCcw, RefreshCw, IndianRupee } from 'lucide-react';
import { Product, StockRequest, ActivityLog, ReturnItem, PurchaseOrder } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell } from 'recharts';

interface StoreOps360Props {
  products: Product[];
  requests: StockRequest[];
  returns: ReturnItem[];
  pos: PurchaseOrder[];
  onTileClick: (tab: string) => void;
  logs: ActivityLog[];
}

export default function StoreOps360({ products, requests, returns, pos, onTileClick, logs }: StoreOps360Props) {
  const pendingRequests = requests.filter(r => r.status === 'Pending').length;
  const criticalItems = products.filter(p => p.currentStock <= p.minLevel).length;
  const awaitingDelivery = pos.filter(po => po.status === 'Awaiting Delivery').length;
  const issuedItems = 124; // Mocked
  const returnedItems = returns.filter(r => r.type === 'Internal').length;
  const purchaseReturns = returns.filter(r => r.type === 'Purchase').length;

  const departmentData = [
    { name: 'CSE', value: 45 },
    { name: 'MECH', value: 25 },
    { name: 'CHEM', value: 15 },
    { name: 'ADMIN', value: 15 },
  ];

  const orderVsReturnData = [
    { name: 'Ordered', value: 120, color: '#0052CC' },
    { name: 'Returned', value: 12, color: '#EF4444' },
    { name: 'Damaged', value: 5, color: '#F59E0B' },
  ];

  const summaryTiles = [
    { id: 'inventory', label: 'Total Stock Items', value: products.length, icon: Package, color: 'text-primary', bg: 'bg-primary/5', trend: 'Healthy' },
    { id: 'inventory', label: 'Pending Requests', value: pendingRequests, icon: ClipboardList, color: 'text-amber-600', bg: 'bg-amber-50', trend: 'Action Needed' },
    { id: 'procurement', label: 'Awaiting Delivery', value: awaitingDelivery, icon: Truck, color: 'text-blue-600', bg: 'bg-blue-50', trend: 'In Transit' },
    { id: 'inventory', label: 'Staff Returns', value: returnedItems, icon: RotateCcw, color: 'text-indigo-600', bg: 'bg-indigo-50', trend: 'Processing' },
    { id: 'procurement', label: 'Purchase Returns', value: purchaseReturns, icon: RefreshCw, color: 'text-teal-600', bg: 'bg-teal-50', trend: 'Actionable' },
    { id: 'procurement', label: 'Fulfillment Rate', value: '92.4%', icon: TrendingUp, color: 'text-success', bg: 'bg-success/5', trend: 'Growing' },
    { id: 'procurement', label: 'Order Commitment', value: `₹${pos.reduce((acc, p) => acc + p.totalAmount, 0).toLocaleString()}`, icon: IndianRupee, color: 'text-primary', bg: 'bg-primary/5', trend: 'Budgeted' },
    { id: 'inventory', label: 'Critical Alerts', value: criticalItems, icon: AlertTriangle, color: 'text-red-500', bg: 'bg-red-50', trend: 'Urgent' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-[1400px] mx-auto p-10">
      <div>
        <h1 className="text-3xl font-extrabold text-text-main tracking-tight uppercase">StoreOps 360*</h1>
        <p className="text-text-sub text-sm mt-1">Real-time intelligence and live operational pulse for SRM College inventory management.</p>
      </div>

      {/* Summary Tiles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {summaryTiles.map((stat) => (
          <button 
            key={stat.label} 
            onClick={() => onTileClick(stat.id)}
            className="glass-card p-6 flex flex-col justify-between group hover:border-primary transition-all duration-300 text-left"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={stat.bg + " p-2.5 rounded-lg"}>
                <stat.icon className={stat.color} size={20} />
              </div>
              <ArrowRight size={14} className="text-text-sub opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-text-sub uppercase tracking-wider mb-1">{stat.label}</p>
              <h3 className="text-2xl font-black text-text-main">{stat.value}</h3>
              <p className={`text-[10px] font-bold mt-2 flex items-center gap-1 ${stat.trend === 'Urgent' ? 'text-red-500' : 'text-success'}`}>
                {stat.trend}
              </p>
            </div>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Requests by Department */}
        <div className="glass-card p-8">
          <h2 className="font-bold text-text-main text-base uppercase tracking-wider mb-8">Requests by Department</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={departmentData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#DFE1E6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#5E6C84', fontWeight: 600 }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#5E6C84', fontWeight: 600 }} />
                <Tooltip cursor={{ fill: '#F4F5F7' }} />
                <Bar dataKey="value" fill="#0052CC" radius={[4, 4, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Ordered vs Returned/Damaged */}
        <div className="glass-card p-8">
          <h2 className="font-bold text-text-main text-base uppercase tracking-wider mb-8">Ordered vs Returned/Damaged</h2>
          <div className="flex items-center justify-center h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={orderVsReturnData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                  stroke="none"
                >
                  {orderVsReturnData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            {orderVsReturnData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: item.color }}></div>
                <span className="text-[10px] font-bold text-text-sub uppercase tracking-wider">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity Pulse */}
      <div className="glass-card overflow-hidden">
        <div className="p-6 border-b border-border bg-bg/20 flex items-center justify-between">
          <h2 className="font-bold text-text-main text-base uppercase tracking-wider flex items-center gap-2">
            Real-time Activity Pulse <span className="w-2 h-2 rounded-full bg-success animate-pulse"></span>
          </h2>
          <Clock size={16} className="text-text-sub" />
        </div>
        <div className="divide-y divide-border">
          {logs.map((log) => (
            <div key={log.id} className="p-6 hover:bg-bg/10 transition-colors flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs shrink-0">
                {log.user[0]}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-bold text-text-main">{log.action}</h4>
                  <span className="text-[10px] font-bold text-text-sub">{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
                <p className="text-xs text-text-sub line-clamp-1">{log.details}</p>
                <p className="text-[10px] text-primary font-bold mt-1">BY: {log.user.toUpperCase()}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
