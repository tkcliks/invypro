import React, { useState } from 'react';
import { Plus, Search, FileText, Clipboard, History, ArrowDownToLine, ChevronDown, CheckCircle2, AlertCircle, X, Download, Filter } from 'lucide-react';
import { Product, GRN, Vendor, Category, ProductUnit, UserRole, GRNItem } from '../types';

interface InventoryPageProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  grns: GRN[];
  setGrns: React.Dispatch<React.SetStateAction<GRN[]>>;
  vendors: Vendor[];
  categories: Category[];
  units: ProductUnit[];
  role: UserRole;
}

export default function InventoryPage({ 
  products, setProducts, 
  grns, setGrns, 
  vendors, categories, units, 
  role 
}: InventoryPageProps) {
  const [activeTab, setActiveTab] = useState('stock');
  const [showGRNModal, setShowGRNModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // GRN Form State
  const [grnForm, setGrnForm] = useState<Partial<GRN>>({
    items: [],
    date: new Date().toISOString(),
  });

  const [currentGRNItem, setCurrentGRNItem] = useState<Partial<GRNItem>>({});

  const handleAddGRNItem = () => {
    if (!currentGRNItem.productId || !currentGRNItem.receivedQty) return;
    
    const product = products.find(p => p.id === currentGRNItem.productId);
    const item: GRNItem = {
      id: Math.random().toString(),
      productId: currentGRNItem.productId,
      productName: product?.name || '',
      orderedQty: currentGRNItem.orderedQty || 0,
      receivedQty: currentGRNItem.receivedQty || 0,
      unitRate: currentGRNItem.unitRate || 0,
      discount: currentGRNItem.discount || 0,
      gstType: 'CGST/SGST',
      gstPercentage: 18,
      taxAmount: ((currentGRNItem.receivedQty || 0) * (currentGRNItem.unitRate || 0)) * 0.18,
      netValue: ((currentGRNItem.receivedQty || 0) * (currentGRNItem.unitRate || 0)) * 1.18
    };

    setGrnForm(prev => ({
      ...prev,
      items: [...(prev.items || []), item]
    }));
    setCurrentGRNItem({});
  };

  const handleSaveGRN = () => {
    const newGRN: GRN = {
      id: Math.random().toString(),
      grnNumber: `GRN-${Math.floor(Math.random() * 90000) + 10000}`,
      date: grnForm.date || new Date().toISOString(),
      poReference: grnForm.poReference || '',
      invoiceNumber: grnForm.invoiceNumber || '',
      vendorId: grnForm.vendorId || '',
      vendorName: vendors.find(v => v.id === grnForm.vendorId)?.name || '',
      items: grnForm.items || [],
      totalTax: (grnForm.items || []).reduce((acc, i) => acc + i.taxAmount, 0),
      totalDiscount: (grnForm.items || []).reduce((acc, i) => acc + i.discount, 0),
      finalAmount: (grnForm.items || []).reduce((acc, i) => acc + i.netValue, 0),
      createdBy: 'Admin',
      status: 'Completed'
    };

    setGrns(prev => [newGRN, ...prev]);
    
    // Update Stock
    setProducts(prev => prev.map(p => {
      const grnItem = newGRN.items.find(i => i.productId === p.id);
      if (grnItem) {
        return { ...p, currentStock: p.currentStock + grnItem.receivedQty };
      }
      return p;
    }));

    setShowGRNModal(false);
    setGrnForm({ items: [], date: new Date().toISOString() });
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-text-main tracking-tight">Stock Inventory</h1>
          <p className="text-text-sub text-sm mt-1 font-medium">Manage and audit institutional asset levels across stores.</p>
        </div>
        {role === 'Admin' && (
          <button 
            onClick={() => setShowGRNModal(true)}
            className="btn-primary"
          >
            <ArrowDownToLine size={16} />
            Create Good Receipt
          </button>
        )}
      </div>

      <div className="flex border-b border-border">
        {[
          { id: 'stock', label: 'Store Inventory', icon: Clipboard, count: products.length },
          { id: 'history', label: 'Receipt Logs', icon: History, count: grns.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-8 py-3 text-[11px] font-bold uppercase tracking-widest transition-all border-b-2 flex items-center gap-2 ${
              activeTab === tab.id 
              ? 'border-primary text-primary' 
              : 'border-transparent text-text-sub hover:text-text-main'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
            <span className={`px-2 py-0.5 rounded text-[10px] ${
              activeTab === tab.id ? 'bg-primary/10 text-primary' : 'bg-bg text-text-sub'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      <div className="glass-card">
        <div className="p-4 border-b border-border flex flex-col sm:flex-row items-center justify-between gap-4 bg-bg/50">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-sub/60" size={14} />
            <input 
              type="text" 
              placeholder="Search store by product name..."
              className="w-full pl-9 pr-4 py-2 bg-surface border border-border rounded-md text-sm focus:ring-1 focus:ring-primary h-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="bg-red-50 text-red-600 px-3 py-1.5 rounded-md text-[10px] font-bold border border-red-100 uppercase flex items-center gap-1.5">
              <AlertCircle size={12} />
              {products.filter(p => p.currentStock <= p.minLevel).length} Low Stock Units
            </div>
            <button className="btn-ghost flex items-center border border-border bg-surface h-10 px-4">
              <Filter size={14} className="mr-2" /> Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto min-h-[400px]">
          {activeTab === 'stock' ? (
            <table className="w-full text-left">
              <thead>
                <tr className="bg-bg border-b border-border">
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Asset Description</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Classification</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Audit Threshold</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Active Stock</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase())).map((product) => (
                  <tr key={product.id} className="hover:bg-bg/20 transition-colors">
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm font-bold text-text-main">{product.name}</p>
                        <p className="text-[10px] text-text-sub font-bold uppercase tracking-tight">UNIT: {units.find(u => u.id === product.unitId)?.name || 'Nos'}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-[10px] font-bold text-text-sub border border-border px-2 py-0.5 rounded bg-bg uppercase">
                        {categories.find(c => c.id === product.categoryId)?.name || 'General'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs font-mono font-bold text-text-sub">{product.minLevel}</td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className={`text-sm font-bold ${product.currentStock <= product.minLevel ? 'text-red-600' : 'text-text-main'}`}>{product.currentStock}</span>
                        <div className="w-24 bg-border/40 h-1.5 rounded-full mt-1.5 overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${product.currentStock <= product.minLevel ? 'bg-red-500' : 'bg-primary'}`}
                            style={{ width: `${Math.min((product.currentStock / (product.minLevel * 2)) * 100, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`status-pill ${
                        product.currentStock <= product.minLevel 
                        ? 'bg-red-50 text-red-700' 
                        : ''
                      }`}>
                        {product.currentStock <= product.minLevel ? 'Critical Reorder' : 'Healthy'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-left">
              <thead>
                <tr className="bg-bg border-b border-border">
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Receipt Identifier</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Source Vendor</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">References</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Valuation</th>
                  <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {grns.map((grn) => (
                  <tr key={grn.id} className="hover:bg-bg/20 transition-colors">
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-text-main tracking-tight">{grn.grnNumber}</p>
                      <p className="text-[10px] text-text-sub font-bold uppercase">{new Date(grn.date).toLocaleDateString()}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-text-main">{grn.vendorName}</p>
                      <span className="text-[9px] font-bold bg-primary/5 text-primary px-1.5 py-0.5 rounded border border-primary/10 uppercase">Verified Vendor</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-1">
                        <span className="text-[10px] font-bold text-text-sub uppercase tracking-widest">PO: {grn.poReference}</span>
                        <span className="text-[10px] font-bold text-text-sub uppercase tracking-widest">INV: {grn.invoiceNumber}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-text-main">₹{grn.finalAmount.toLocaleString()}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 hover:bg-bg rounded-lg text-text-sub transition-colors border border-transparent hover:border-border shadow-none hover:shadow-sm">
                        <Download size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* GRN Creation Modal */}
      {showGRNModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden animate-in zoom-in duration-200 flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0">
              <div>
                <h3 className="text-xl font-bold text-slate-900 uppercase tracking-tight">Create Goods Received Note</h3>
                <p className="text-xs text-slate-500 mt-1 font-medium">Record incoming vendor supplies directly to Central Store</p>
              </div>
              <button onClick={() => setShowGRNModal(false)} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400">
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-8">
              {/* Header Info */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label className="input-label">Vendor Name</label>
                  <select 
                    className="form-input"
                    onChange={e => setGrnForm({...grnForm, vendorId: e.target.value})}
                  >
                    <option value="">Select Vendor</option>
                    {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="input-label">PO Reference</label>
                  <input 
                    type="text" className="form-input" placeholder="PO-12345"
                    onChange={e => setGrnForm({...grnForm, poReference: e.target.value})}
                  />
                </div>
                <div>
                  <label className="input-label">Invoice Number</label>
                  <input 
                    type="text" className="form-input" placeholder="INV-001"
                    onChange={e => setGrnForm({...grnForm, invoiceNumber: e.target.value})}
                  />
                </div>
                <div>
                  <label className="input-label">Received Date</label>
                  <input 
                    type="date" className="form-input text-xs"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    onChange={e => setGrnForm({...grnForm, date: e.target.value})}
                  />
                </div>
              </div>

              {/* Item Entry Section */}
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Add Items Per Receipt</h4>
                <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
                  <div className="md:col-span-2">
                    <label className="input-label">Select Item</label>
                    <select 
                      className="form-input"
                      value={currentGRNItem.productId || ''}
                      onChange={e => setCurrentGRNItem({...currentGRNItem, productId: e.target.value})}
                    >
                      <option value="">Choose item...</option>
                      {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="input-label">Ordered Qty</label>
                    <input 
                      type="number" className="form-input"
                      onChange={e => setCurrentGRNItem({...currentGRNItem, orderedQty: Number(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="input-label">Received Qty</label>
                    <input 
                      type="number" className="form-input"
                      onChange={e => setCurrentGRNItem({...currentGRNItem, receivedQty: Number(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="input-label">Unit Rate (₹)</label>
                    <input 
                      type="number" className="form-input"
                      onChange={e => setCurrentGRNItem({...currentGRNItem, unitRate: Number(e.target.value)})}
                    />
                  </div>
                  <div className="flex items-end">
                    <button 
                      onClick={handleAddGRNItem}
                      className="btn-primary w-full py-2.5"
                    >
                      <Plus size={16} /> Add
                    </button>
                  </div>
                </div>
              </div>

              {/* Items List */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3 font-bold text-slate-600">Item Name</th>
                      <th className="px-4 py-3 font-bold text-slate-600">Ordered</th>
                      <th className="px-4 py-3 font-bold text-slate-600">Received</th>
                      <th className="px-4 py-3 font-bold text-slate-600">Rate</th>
                      <th className="px-4 py-3 font-bold text-slate-600">Tax (18%)</th>
                      <th className="px-4 py-3 font-bold text-slate-600 text-right">Net Value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {grnForm.items?.map((item, idx) => (
                      <tr key={idx}>
                        <td className="px-4 py-3 font-medium text-slate-900">{item.productName}</td>
                        <td className="px-4 py-3 text-slate-500">{item.orderedQty}</td>
                        <td className="px-4 py-3 font-semibold text-slate-900">{item.receivedQty}</td>
                        <td className="px-4 py-3 text-slate-600">₹{item.unitRate}</td>
                        <td className="px-4 py-3 text-slate-500">₹{item.taxAmount.toFixed(2)}</td>
                        <td className="px-4 py-3 text-right font-bold text-slate-900">₹{item.netValue.toLocaleString()}</td>
                      </tr>
                    ))}
                    {(!grnForm.items || grnForm.items.length === 0) && (
                      <tr>
                        <td colSpan={6} className="px-4 py-8 text-center text-slate-400 italic">No items added to this GRN yet.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-8">
                <div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase">Items Added</p>
                  <p className="text-xl font-bold text-slate-900">{grnForm.items?.length || 0}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase">Total Net Amount</p>
                  <p className="text-xl font-bold text-primary">₹{(grnForm.items?.reduce((acc, i) => acc + i.netValue, 0) || 0).toLocaleString()}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 w-full md:w-auto">
                <button 
                  onClick={() => setShowGRNModal(false)}
                  className="btn-ghost"
                >
                  Discard Draft
                </button>
                <button 
                  disabled={!grnForm.items?.length}
                  onClick={handleSaveGRN}
                  className="btn-primary w-full md:w-auto shadow-lg shadow-primary/30"
                >
                  <CheckCircle2 size={18} />
                  Complete GRN
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
