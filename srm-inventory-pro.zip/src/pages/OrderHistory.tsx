import React, { useState } from 'react';
import { Search, Filter, Download, ExternalLink, Calendar, User, Package, History } from 'lucide-react';
import { PurchaseOrder, Vendor, Product } from '../types';

interface OrderHistoryProps {
  pos: PurchaseOrder[];
  vendors: Vendor[];
  products: Product[];
  isNested?: boolean;
}

export default function OrderHistory({ pos, vendors, products, isNested }: OrderHistoryProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [vendorFilter, setVendorFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);

  const historicalOrders = pos.filter(po => 
    po.status === 'Fulfilled' || po.status === 'Cancelled'
  );

  const filteredOrders = historicalOrders.filter(po => {
    const matchesSearch = po.poNumber.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         po.vendorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         po.items.some(item => item.productName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesVendor = vendorFilter ? po.vendorId === vendorFilter : true;
    const matchesStatus = statusFilter ? po.status === statusFilter : true;
    return matchesSearch && matchesVendor && matchesStatus;
  });

  const content = (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {!isNested && (
        <div>
          <h1 className="text-3xl font-extrabold text-text-main tracking-tight uppercase">Order History</h1>
          <p className="text-text-sub text-sm mt-1">Audit log of all fulfilled and cancelled procurement transactions.</p>
        </div>
      )}

      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-surface p-4 rounded-xl border border-border shadow-sm">
        <div className="flex flex-1 gap-3 w-full md:w-auto">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-sub" size={16} />
            <input 
              type="text" 
              placeholder="Search PO number or vendor..."
              className="form-input pl-10 h-11 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <select 
            className="form-input h-11 w-48 text-xs font-bold"
            value={vendorFilter}
            onChange={(e) => setVendorFilter(e.target.value)}
          >
            <option value="">All Vendors</option>
            {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
          </select>
          <select 
            className="form-input h-11 w-40 text-xs font-bold"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">All Statuses</option>
            <option value="Fulfilled">Fulfilled</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
        <button className="btn-ghost flex items-center gap-2 h-11 px-4 border border-border bg-white text-xs font-bold uppercase tracking-widest">
          <Download size={14} /> Export CSV
        </button>
      </div>

      <div className="glass-card overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Order Detail</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Vendor</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Date</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Value</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Outcome</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {filteredOrders.length > 0 ? filteredOrders.map((po) => (
              <tr key={po.id} className="hover:bg-bg/10 transition-colors group">
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-text-main">{po.poNumber}</p>
                  <p className="text-[10px] text-text-sub font-mono">{po.items.length} Line Items</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-medium text-text-main">{po.vendorName}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-xs font-bold text-text-sub">{new Date(po.orderDate).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-black text-text-main tabular-nums">₹{po.totalAmount.toLocaleString()}</p>
                </td>
                <td className="px-6 py-4">
                  <span className={`status-pill ${
                    po.status === 'Fulfilled' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'
                  }`}>
                    {po.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => setSelectedPO(po)}
                    className="p-2 hover:bg-primary/10 rounded-lg text-primary transition-colors inline-flex items-center gap-1.5 text-[10px] font-bold uppercase"
                  >
                    Details <ExternalLink size={12} />
                  </button>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={6} className="px-6 py-20 text-center">
                  <div className="flex flex-col items-center opacity-40">
                    <History size={48} className="mb-4" />
                    <p className="text-sm font-bold uppercase tracking-widest">No historical records found</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* PO Detail Modal */}
      {selectedPO && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-surface rounded-xl w-full max-w-3xl shadow-2xl border border-border overflow-hidden">
            <div className="p-6 border-b border-border flex items-center justify-between bg-bg/20">
              <div>
                <h3 className="text-lg font-bold text-text-main uppercase tracking-tight">Purchase Order: {selectedPO.poNumber}</h3>
                <div className="flex items-center gap-3 mt-1">
                  <span className={`status-pill ${selectedPO.status === 'Fulfilled' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-600'}`}>
                    {selectedPO.status}
                  </span>
                  <span className="text-[10px] text-text-sub font-bold flex items-center gap-1"><Calendar size={12} /> {new Date(selectedPO.orderDate).toLocaleDateString()}</span>
                </div>
              </div>
              <button onClick={() => setSelectedPO(null)} className="p-2 hover:bg-bg rounded-full text-text-sub">
                <History className="rotate-45" size={24} />
              </button>
            </div>

            <div className="p-8 grid grid-cols-3 gap-8 border-b border-border">
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Vendor Entity</label>
                  <p className="text-sm font-bold text-text-main">{selectedPO.vendorName}</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Delivery Lead Time</label>
                  <p className="text-sm font-medium text-text-sub italic">Closed Cycle</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Commercial Value</label>
                  <p className="text-lg font-black text-primary tabular-nums">₹{selectedPO.totalAmount.toLocaleString()}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">System Audit ID</label>
                  <p className="text-xs font-mono text-text-sub">{selectedPO.id}</p>
                </div>
              </div>
            </div>

            <div className="p-0 overflow-x-auto max-h-[300px]">
              <table className="w-full text-left">
                <thead className="sticky top-0 bg-bg z-10 border-b border-border">
                  <tr>
                    <th className="px-8 py-3 text-[10px] font-bold text-text-sub uppercase">Item / Asset</th>
                    <th className="px-8 py-3 text-[10px] font-bold text-text-sub uppercase text-center">Qty</th>
                    <th className="px-8 py-3 text-[10px] font-bold text-text-sub uppercase text-right">Unit Rate</th>
                    <th className="px-8 py-3 text-[10px] font-bold text-text-sub uppercase text-right">Extended</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {selectedPO.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-primary/5 transition-colors">
                      <td className="px-8 py-4 flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-bg flex items-center justify-center text-primary"><Package size={14} /></div>
                        <span className="text-sm font-bold text-text-main">{item.productName}</span>
                      </td>
                      <td className="px-8 py-4 text-sm font-bold text-text-main text-center tabular-nums">{item.quantity}</td>
                      <td className="px-8 py-4 text-sm font-bold text-text-sub text-right tabular-nums">₹{item.unitPrice.toLocaleString()}</td>
                      <td className="px-8 py-4 text-sm font-black text-text-main text-right tabular-nums">₹{(item.quantity * item.unitPrice).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-8 bg-bg/30 flex justify-end">
              <button 
                onClick={() => setSelectedPO(null)}
                className="btn-primary px-8 h-12 text-xs uppercase tracking-widest font-black"
              >
                Close Audit View
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return isNested ? content : (
    <div className="max-w-[1400px] mx-auto p-10">
      {content}
    </div>
  );
}
