import React, { useState } from 'react';
import { Package, ClipboardList, RefreshCw, Search, Filter, Plus, ChevronRight, AlertCircle, Trash2, Edit2, CheckCircle2, XCircle } from 'lucide-react';
import { Product, StockRequest, UserRole, ReturnItem, Department, ActivityLog } from '../types';

interface StoreInventoryProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  requests: StockRequest[];
  setRequests: React.Dispatch<React.SetStateAction<StockRequest[]>>;
  returns: ReturnItem[];
  setReturns: React.Dispatch<React.SetStateAction<ReturnItem[]>>;
  departments: Department[];
  role: UserRole;
  addLog: (action: string, details: string) => void;
}

export default function StoreInventory({ 
  products, setProducts, 
  requests, setRequests, 
  returns, setReturns,
  departments,
  role,
  addLog
}: StoreInventoryProps) {
  const [activeSubTab, setActiveSubTab] = useState('requests');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<StockRequest | null>(null);
  const [showAddRequest, setShowAddRequest] = useState(false);

  // New Request Form State
  const [newRequest, setNewRequest] = useState<Partial<StockRequest>>({
    priority: 'Medium',
    status: 'Pending',
    requestedDate: new Date().toISOString()
  });

  const handleAction = (requestId: string, action: 'Approve' | 'Reject', remarks: string) => {
    setRequests(prev => prev.map(req => {
      if (req.id === requestId) {
        const newStatus = action === 'Approve' ? 'Approved' : 'Rejected';
        addLog(`Request ${action}d`, `${action}d request ${req.requestNumber} - Items: ${req.productName}`);
        return { 
          ...req, 
          status: newStatus, 
          approverName: 'Admin User',
          remarks 
        };
      }
      return req;
    }));
    setSelectedRequest(null);
  };

  const createRequest = () => {
    if (!newRequest.productId || !newRequest.requestedQty || !newRequest.departmentId) return;

    const product = products.find(p => p.id === newRequest.productId);
    const dept = departments.find(d => d.id === newRequest.departmentId);

    const request: StockRequest = {
      id: Math.random().toString(36).substr(2, 9),
      requestNumber: `REQ-${Math.floor(Math.random() * 90000) + 10000}`,
      productId: newRequest.productId,
      productName: product?.name || '',
      requestedQty: Number(newRequest.requestedQty),
      priority: newRequest.priority as any,
      reason: newRequest.reason || '',
      requesterName: 'Current User',
      departmentId: newRequest.departmentId,
      departmentName: dept?.name || '',
      requestedDate: new Date().toISOString(),
      status: 'Pending',
      approvalChain: []
    };

    setRequests(prev => [request, ...prev]);
    addLog('New Request Created', `Request ${request.requestNumber} for ${request.productName} raised.`);
    setShowAddRequest(false);
    setNewRequest({ priority: 'Medium', status: 'Pending', requestedDate: new Date().toISOString() });
  };

  const renderRequests = () => (
    <div className="glass-card">
      <div className="p-4 border-b border-border flex flex-col sm:flex-row items-center justify-between gap-4 bg-bg/50">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-sub" size={14} />
          <input 
            type="text" 
            placeholder="Search request #, item or requester..."
            className="form-input pl-9 pr-4 py-2 text-xs"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-ghost text-xs border border-border bg-surface px-4 py-2">
            <Filter size={14} className="mr-2" /> Filter
          </button>
          <button onClick={() => setShowAddRequest(true)} className="btn-primary text-xs py-2">
            <Plus size={14} /> Create Request
          </button>
        </div>
      </div>
      <div className="overflow-x-auto min-h-[400px]">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Request #</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Item & Dept</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Requester</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Quantity</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {requests.filter(r => r.requestNumber.toLowerCase().includes(searchQuery.toLowerCase()) || r.productName.toLowerCase().includes(searchQuery.toLowerCase())).map((req) => (
              <tr 
                key={req.id} 
                className="hover:bg-bg/10 cursor-pointer transition-colors"
                onClick={() => setSelectedRequest(req)}
              >
                <td className="px-6 py-4">
                  <span className="text-sm font-bold text-primary hover:underline">{req.requestNumber}</span>
                  <p className="text-[10px] text-text-sub font-bold mt-0.5">{new Date(req.requestedDate).toLocaleDateString()}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-text-main">{req.productName}</p>
                  <p className="text-[10px] text-text-sub font-bold uppercase tracking-widest">{req.departmentName}</p>
                </td>
                <td className="px-6 py-4">
                  <p className="text-xs font-bold text-text-main">{req.requesterName}</p>
                  <p className="text-[10px] text-text-sub italic">L1: {req.approverName || 'Pending'}</p>
                </td>
                <td className="px-6 py-4">
                  <span className="text-xs font-bold text-text-main">{req.requestedQty} Units</span>
                </td>
                <td className="px-6 py-4">
                  <span className={`status-pill ${
                    req.status === 'Pending' ? 'bg-amber-50 text-amber-700' :
                    req.status === 'Approved' ? 'bg-blue-50 text-blue-700' :
                    req.status === 'Rejected' ? 'bg-red-50 text-red-700' :
                    'bg-green-50 text-green-700'
                  }`}>
                    {req.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderStock = () => (
    <div className="glass-card">
      <div className="p-4 border-b border-border flex items-center justify-between bg-bg/50">
        <h2 className="text-sm font-bold text-text-main uppercase tracking-widest flex items-center gap-2">
          On-Hand Inventory <span className="status-pill bg-primary/10 text-primary">{products.length} Total</span>
        </h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-bold">
            <div className="w-3 h-3 bg-red-500 rounded-sm"></div> <span className="text-text-sub">Critical</span>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold">
            <div className="w-3 h-3 bg-primary rounded-sm"></div> <span className="text-text-sub">Healthy</span>
          </div>
        </div>
      </div>
      <div className="overflow-x-auto min-h-[400px]">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Item Name</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Threshold Audit</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Live Stock</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {products.map((p) => (
              <tr key={p.id} className="hover:bg-bg/10 transition-colors">
                <td className="px-6 py-4 font-bold text-text-main text-sm">{p.name}</td>
                <td className="px-6 py-4 text-xs font-mono text-text-sub">MIN: {p.minLevel}</td>
                <td className="px-6 py-4">
                  <div className="flex items-baseline gap-2">
                    <span className={`text-sm font-black ${p.currentStock <= p.minLevel ? 'text-red-500' : 'text-text-main'}`}>{p.currentStock}</span>
                    <div className="flex-1 w-32 bg-border/40 h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-700 ${p.currentStock <= p.minLevel ? 'bg-red-500' : 'bg-primary'}`}
                        style={{ width: `${Math.min((p.currentStock / (p.minLevel * 2.5)) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  {p.currentStock <= p.minLevel ? (
                    <span className="flex items-center gap-1.5 text-xs text-red-500 font-bold animate-pulse">
                      <AlertCircle size={14} /> Reorder Triggered
                    </span>
                  ) : (
                    <span className="text-xs text-success font-bold flex items-center gap-1.5">
                      <CheckCircle2 size={14} /> Sufficient
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderReturns = () => (
    <div className="glass-card">
      <div className="p-4 border-b border-border bg-bg/50 flex items-center justify-between">
        <h2 className="text-sm font-bold text-text-main uppercase tracking-widest flex items-center gap-2">
          Returns Ledger <span className="status-pill bg-primary/10 text-primary">{returns.length} Active</span>
        </h2>
        <div className="flex items-center gap-4 text-[10px] font-bold">
          <div className="flex items-center gap-1.5"><div className="w-2 h-2 bg-red-500 rounded-px"></div> EXPIRED</div>
          <div className="flex items-center gap-1.5"><div className="w-2 h-2 bg-success rounded-px"></div> VALID</div>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Asset Info</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Return Window Audit</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Type</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {returns.map((ret, idx) => {
              const daysIn = idx * 10; // Mocking days passed
              const windowLimit = 30; // 30 day window
              const percentage = (daysIn / windowLimit) * 100;
              const isExpired = percentage >= 100;
              
              return (
                <tr key={ret.id} className="hover:bg-bg/10 transition-colors">
                  <td className="px-6 py-4">
                    <p className="text-sm font-bold text-text-main">{ret.productName}</p>
                    <p className="text-[10px] text-text-sub font-mono uppercase">QTY: {ret.quantity}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[10px] font-bold">
                        <span className={isExpired ? 'text-red-500' : 'text-text-sub'}>{daysIn} Days Passed</span>
                        <span className="text-text-sub">30D LIMIT</span>
                      </div>
                      <div className="w-48 h-1.5 bg-border/40 rounded-full overflow-hidden">
                        <div 
                          className={`h-full transition-all duration-1000 ${isExpired ? 'bg-red-500' : 'bg-success'}`}
                          style={{ width: `${Math.min(percentage, 100)}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-[10px] font-bold text-text-sub uppercase px-2 py-0.5 bg-bg border border-border rounded">
                      {ret.type}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`status-pill ${isExpired ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-700'}`}>
                      {isExpired ? 'WINDOW EXPIRED' : ret.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-[1400px] mx-auto p-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-text-main tracking-tight">Store & Inventory</h1>
          <p className="text-text-sub text-sm mt-1">Holistic operations hub for stock tracking and request fulfillment.</p>
        </div>
      </div>

      <div className="flex border-b border-border">
        {[
          { id: 'requests', label: 'Pending Requests', icon: ClipboardList, count: requests.filter(r => r.status === 'Pending').length },
          { id: 'stock', label: 'On-Hand Stock', icon: Package, count: products.length },
          { id: 'returns', label: 'Returns Management', icon: RefreshCw, count: returns.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`px-8 py-3 text-[11px] font-bold uppercase tracking-widest transition-all border-b-2 flex items-center gap-2 ${
              activeSubTab === tab.id 
              ? 'border-primary text-primary' 
              : 'border-transparent text-text-sub hover:text-text-main'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
            <span className={`px-2 py-0.5 rounded text-[10px] ${
              activeSubTab === tab.id ? 'bg-primary/10 text-primary' : 'bg-bg text-text-sub'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      <div className="min-h-[600px]">
        {activeSubTab === 'requests' && renderRequests()}
        {activeSubTab === 'stock' && renderStock()}
        {activeSubTab === 'returns' && renderReturns()}
      </div>

      {/* Request Details Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-surface rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden border border-border">
            <div className="p-6 border-b border-border flex items-center justify-between bg-bg/20">
              <div>
                <h3 className="text-lg font-bold text-text-main">Request Detail: {selectedRequest.requestNumber}</h3>
                <p className="text-[11px] text-text-sub font-bold uppercase tracking-widest mt-1">SRM Institutional Asset Request</p>
              </div>
              <button 
                onClick={() => setSelectedRequest(null)}
                className="p-2 hover:bg-bg rounded-lg border border-transparent hover:border-border transition-all"
              >
                <ChevronRight className="rotate-90 sm:rotate-0" size={20} />
              </button>
            </div>
            
            <div className="p-8 grid grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-2">Item Requested</label>
                  <p className="text-base font-bold text-text-main">{selectedRequest.productName}</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Department</label>
                  <p className="text-sm font-bold text-text-main uppercase">{selectedRequest.departmentName}</p>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Requested Quantity</label>
                  <p className="text-sm font-bold text-text-main">{selectedRequest.requestedQty} Units</p>
                </div>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-2">Priority Level</label>
                  <span className={`px-3 py-1 rounded text-[10px] font-black uppercase ${
                    selectedRequest.priority === 'High' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-blue-50 text-blue-600 border border-blue-100'
                  }`}>
                    {selectedRequest.priority} PRIORITY
                  </span>
                </div>
                <div>
                  <label className="text-[10px] font-bold text-text-sub uppercase tracking-widest block mb-1">Requester justification</label>
                  <p className="text-xs text-text-sub leading-relaxed italic">"{selectedRequest.reason || 'No justification provided'}"</p>
                </div>
              </div>
            </div>

            {role === 'Admin' && selectedRequest.status === 'Pending' && (
              <div className="p-6 bg-primary/5 border-t border-primary/10 flex items-center justify-between">
                <div className="flex-1 mr-6">
                  <input 
                    type="text" 
                    placeholder="Approver remarks (mandatory for rejection)..."
                    className="form-input text-xs w-full bg-surface"
                    id="approver-remarks"
                  />
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => handleAction(selectedRequest.id, 'Reject', (document.getElementById('approver-remarks') as HTMLInputElement).value)}
                    className="btn-ghost text-red-600 hover:bg-red-50 border border-red-100 text-xs px-6 py-2"
                  >
                    Reject
                  </button>
                  <button 
                    onClick={() => handleAction(selectedRequest.id, 'Approve', (document.getElementById('approver-remarks') as HTMLInputElement).value)}
                    className="btn-primary text-xs px-6 py-2"
                  >
                    Approve Request
                  </button>
                </div>
              </div>
            )}
            
            {selectedRequest.status !== 'Pending' && (
              <div className="p-6 bg-slate-50 border-t border-border">
                <p className="text-xs font-bold text-text-sub uppercase tracking-widest mb-2">Workflow Finalized</p>
                <div className="flex items-center gap-3">
                  <div className={`p-1.5 rounded-full ${selectedRequest.status === 'Approved' ? 'bg-success/10 text-success' : 'bg-red-50 text-red-500'}`}>
                    {selectedRequest.status === 'Approved' ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-text-main">{selectedRequest.status === 'Approved' ? 'Approved by' : 'Rejected by'} {selectedRequest.approverName}</p>
                    <p className="text-xs text-text-sub">Remarks: {selectedRequest.remarks || 'No remarks provided'}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Request Modal */}
      {showAddRequest && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-surface rounded-xl w-full max-w-lg shadow-2xl border border-border animate-in zoom-in duration-200">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-bold text-text-main uppercase tracking-widest">New Stock Indent</h3>
              <button onClick={() => setShowAddRequest(false)} className="text-text-sub hover:text-text-main"><XCircle size={20} /></button>
            </div>
            <div className="p-6 space-y-5">
              <div>
                <label className="input-label">Department Selection</label>
                <select 
                  className="form-input h-10"
                  onChange={e => setNewRequest({...newRequest, departmentId: e.target.value})}
                >
                  <option value="">Select Department</option>
                  {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
              <div>
                <label className="input-label">Asset / Item</label>
                <select 
                  className="form-input h-10"
                  onChange={e => setNewRequest({...newRequest, productId: e.target.value})}
                >
                  <option value="">Select Item</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.name} (Stock: {p.currentStock})</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="input-label">Quantity</label>
                  <input 
                    type="number" 
                    className="form-input h-10" 
                    placeholder="0"
                    onChange={e => setNewRequest({...newRequest, requestedQty: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="input-label">Priority</label>
                  <select 
                    className="form-input h-10"
                    onChange={e => setNewRequest({...newRequest, priority: e.target.value as any})}
                    value={newRequest.priority}
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="input-label">Justification / Reason</label>
                <textarea 
                  className="form-input h-24" 
                  placeholder="Why is this requested?"
                  onChange={e => setNewRequest({...newRequest, reason: e.target.value})}
                ></textarea>
              </div>
            </div>
            <div className="p-6 border-t border-border bg-bg/20 flex gap-3 justify-end">
              <button onClick={() => setShowAddRequest(false)} className="btn-ghost px-6">Cancel</button>
              <button onClick={createRequest} className="btn-primary px-8">Submit Indent</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
