import React, { useState } from 'react';
import { Plus, Search, Edit2, Trash2, Filter, Download, MoreHorizontal, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Category, ProductUnit, Vendor, UserRole } from '../types';

interface MastersPageProps {
  categories?: Category[];
  setCategories?: React.Dispatch<React.SetStateAction<Category[]>>;
  units?: ProductUnit[];
  setUnits?: React.Dispatch<React.SetStateAction<ProductUnit[]>>;
  vendors?: Vendor[];
  setVendors?: React.Dispatch<React.SetStateAction<Vendor[]>>;
  role: UserRole;
  isVendorOnly?: boolean;
}

export default function MastersPage({ 
  categories, setCategories, 
  units, setUnits, 
  vendors, setVendors, 
  role, isVendorOnly 
}: MastersPageProps) {
  const [activeSubTab, setActiveSubTab] = useState(isVendorOnly ? 'vendors' : 'categories');
  const [searchQuery, setSearchQuery] = useState('');
  const [showModal, setShowModal] = useState(false);

  // Form State
  const [formData, setFormData] = useState<any>({});

  const handleAdd = () => {
    if (activeSubTab === 'categories' && setCategories) {
      const newCat: Category = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        subCategory: formData.subCategory,
        description: formData.description,
        createdAt: new Date().toISOString()
      };
      setCategories(prev => [...prev, newCat]);
    } else if (activeSubTab === 'units' && setUnits) {
      const newUnit: ProductUnit = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        description: formData.description,
        uom: formData.uom,
        mappings: formData.mappings
      };
      setUnits(prev => [...prev, newUnit]);
    } else if (activeSubTab === 'vendors' && setVendors) {
      const newVendor: Vendor = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData
      };
      setVendors(prev => [...prev, newVendor]);
    }
    setShowModal(false);
    setFormData({});
  };

  const renderTable = () => {
    if (activeSubTab === 'categories') {
      return (
        <table className="w-full text-left">
          <thead>
            <tr className="bg-bg border-b border-border">
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Category Name</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Sub-Category</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Description</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider">Created</th>
              <th className="px-6 py-4 text-[11px] font-bold text-text-sub uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {categories?.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map((cat) => (
              <tr key={cat.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 text-sm font-semibold text-slate-900">{cat.name}</td>
                <td className="px-6 py-4 text-sm text-slate-600">{cat.subCategory}</td>
                <td className="px-6 py-4 text-sm text-slate-500 max-w-xs truncate">{cat.description}</td>
                <td className="px-6 py-4 text-xs text-slate-400">{new Date(cat.createdAt).toLocaleDateString()}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button className="p-1.5 text-slate-400 hover:text-primary transition-colors hover:bg-white rounded border border-transparent hover:border-slate-200"><Edit2 size={14} /></button>
                    <button className="p-1.5 text-slate-400 hover:text-red-500 transition-colors hover:bg-white rounded border border-transparent hover:border-slate-200"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }

    if (activeSubTab === 'units') {
      return (
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Unit Name</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">UOM Type</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Mapping</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {units?.filter(u => u.name.toLowerCase().includes(searchQuery.toLowerCase())).map((unit) => (
              <tr key={unit.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 text-sm font-semibold text-slate-900">{unit.name}</td>
                <td className="px-6 py-4"><span className="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">{unit.uom}</span></td>
                <td className="px-6 py-4 text-sm text-slate-500 italic">{unit.mappings || 'N/A'}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button className="p-1.5 text-slate-400 hover:text-primary transition-colors"><Edit2 size={14} /></button>
                    <button className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }

    if (activeSubTab === 'vendors') {
      return (
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Vendor Info</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Contact</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Tax ID (GST)</th>
              <th className="px-6 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {vendors?.filter(v => v.name.toLowerCase().includes(searchQuery.toLowerCase())).map((vendor) => (
              <tr key={vendor.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-slate-400 text-xs font-bold">
                      {vendor.name[0]}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{vendor.name}</p>
                      <p className="text-[10px] text-slate-500 font-medium">{vendor.companyName}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <p className="text-xs text-slate-600">{vendor.email}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{vendor.phone}</p>
                </td>
                <td className="px-6 py-4">
                  <span className="text-xs font-mono text-slate-600 font-medium uppercase tracking-wider">{vendor.gst}</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button className="p-1.5 text-slate-400 hover:text-primary transition-colors"><Edit2 size={14} /></button>
                    <button className="p-1.5 text-slate-400 hover:text-red-500 transition-colors"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      );
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-text-main tracking-tight">Master Configuration</h1>
          <p className="text-text-sub text-sm mt-1">Manage institutional classifications and external partners</p>
        </div>
        {role === 'Admin' && (
          <button 
            onClick={() => setShowModal(true)}
            className="btn-primary"
          >
            <Plus size={18} />
            Add New {activeSubTab.slice(0, -1)}
          </button>
        )}
      </div>

      {!isVendorOnly && (
        <div className="flex border-b border-slate-200">
          {[
            { id: 'categories', label: 'Item Categories', count: categories?.length },
            { id: 'units', label: 'Product Units', count: units?.length },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`px-6 py-3 text-sm font-bold uppercase tracking-wider transition-all border-b-2 ${
                activeSubTab === tab.id 
                ? 'border-primary text-primary' 
                : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              {tab.label}
              <span className={`ml-2 px-1.5 py-0.5 rounded text-[10px] ${
                activeSubTab === tab.id ? 'bg-primary/10 text-primary' : 'bg-slate-100 text-slate-500'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>
      )}

      <div className="glass-card">
        <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50/30">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
            <input 
              type="text" 
              placeholder={`Search ${activeSubTab}...`}
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:ring-1 focus:ring-primary focus:border-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors">
              <Filter size={14} />
              Filter
            </button>
            <button className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-white border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors">
              <Download size={14} />
              Export
            </button>
          </div>
        </div>

        <div className="overflow-x-auto min-h-[400px]">
          {renderTable()}
        </div>

        {/* Pagination */}
        <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            Showing 10 records per page
          </span>
          <div className="flex items-center gap-2">
            <button className="p-1.5 border border-slate-200 rounded-lg text-slate-400 disabled:opacity-30" disabled>
              <ChevronLeft size={16} />
            </button>
            <button className="p-1.5 border border-slate-200 rounded-lg text-slate-400 hover:bg-slate-50">
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Basic Modal Implementation */}
      {showModal && (
        <div className="fixed inset-0 bg-slate-900/60 z-[60] flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="text-xl font-bold text-slate-900">Add New {activeSubTab.slice(0, -1).toUpperCase()}</h3>
              <button 
                onClick={() => setShowModal(false)}
                className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="modal-content overflow-y-auto max-h-[70vh]">
              <div className="space-y-4">
                {activeSubTab === 'categories' && (
                  <>
                    <div>
                      <label className="input-label">Category Name</label>
                      <input 
                        type="text" className="form-input" placeholder="e.g. Laboratory" 
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="input-label">Sub-Category</label>
                      <input 
                        type="text" className="form-input" placeholder="e.g. Chemicals"
                        onChange={e => setFormData({...formData, subCategory: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="input-label">Description</label>
                      <textarea 
                        className="form-input h-24" placeholder="Brief description..."
                        onChange={e => setFormData({...formData, description: e.target.value})}
                      ></textarea>
                    </div>
                  </>
                )}

                {activeSubTab === 'units' && (
                  <>
                    <div>
                      <label className="input-label">Unit Name</label>
                      <input 
                        type="text" className="form-input" placeholder="e.g. Dozen"
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="input-label">UOM Type</label>
                      <select 
                        className="form-input"
                        onChange={e => setFormData({...formData, uom: e.target.value})}
                      >
                        <option value="Nos">Nos</option>
                        <option value="Box">Box</option>
                        <option value="Pack">Pack</option>
                        <option value="Liters">Liters</option>
                        <option value="Kg">Kg</option>
                      </select>
                    </div>
                    <div>
                      <label className="input-label">Mapping Conversion</label>
                      <input 
                        type="text" className="form-input" placeholder="e.g. 1 Box -> 12 Nos"
                        onChange={e => setFormData({...formData, mappings: e.target.value})}
                      />
                    </div>
                  </>
                )}

                {activeSubTab === 'vendors' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <label className="input-label">Vendor Name / Company</label>
                      <input 
                        type="text" className="form-input" placeholder="Enter name"
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="input-label">Phone</label>
                      <input 
                        type="text" className="form-input" 
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="input-label">Email</label>
                      <input 
                        type="email" className="form-input" 
                        onChange={e => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="input-label">GST Number</label>
                      <input 
                        type="text" className="form-input" placeholder="33AAAAA..."
                        onChange={e => setFormData({...formData, gst: e.target.value})}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-end gap-3">
              <button 
                onClick={() => setShowModal(false)}
                className="btn-ghost"
              >
                Cancel
              </button>
              <button 
                onClick={handleAdd}
                className="btn-primary"
              >
                Save {activeSubTab.slice(0, -1)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
