/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'Admin' | 'Store Manager' | 'Supervisor';

export interface Department {
  id: string;
  name: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  user: string;
  timestamp: string;
  details: string;
}

export interface Category {
  id: string;
  name: string;
  subCategory: string;
  description: string;
  createdAt: string;
}

export interface ProductUnit {
  id: string;
  name: string;
  description: string;
  uom: 'Nos' | 'Box' | 'Pack' | 'Liters' | 'Kg';
  mappings?: string; // e.g. "Box -> Nos"
}

export interface Vendor {
  id: string;
  name: string;
  companyName: string;
  phone: string;
  email: string;
  address: string;
  pan: string;
  bankName: string;
  accountNumber: string;
  ifsc: string;
  branch: string;
  gst: string;
  aadhaar: string;
  imageUrl?: string;
}

export interface Product {
  id: string;
  name: string;
  categoryId: string;
  subCategoryId?: string;
  unitId: string;
  minLevel: number;
  currentStock: number;
  batchNumber?: string;
  expiryDate?: string;
  price: number;
}

export interface GRNItem {
  id: string;
  productId: string;
  productName: string;
  orderedQty: number;
  receivedQty: number;
  unitRate: number;
  discount: number;
  gstType: 'CGST/SGST' | 'IGST';
  gstPercentage: number;
  taxAmount: number;
  netValue: number;
}

export interface GRN {
  id: string;
  grnNumber: string;
  date: string;
  poReference: string;
  invoiceNumber: string;
  vendorId: string;
  vendorName: string;
  items: GRNItem[];
  totalTax: number;
  totalDiscount: number;
  finalAmount: number;
  createdBy: string;
  status: 'Draft' | 'Completed';
}

export interface StockRequest {
  id: string;
  requestNumber: string;
  productId: string;
  productName: string;
  requestedQty: number;
  approvedQty?: number;
  issuedQty?: number;
  priority: 'Low' | 'Medium' | 'High';
  reason: string;
  requesterName: string;
  approverName?: string;
  departmentId: string;
  departmentName: string;
  requestedDate: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Partially Issued' | 'Fully Issued' | 'Closed';
  remarks?: string;
  approvalChain: {
    level: string;
    approver: string;
    action: 'Recommend' | 'Approve' | 'Reject';
    remarks: string;
    date: string;
  }[];
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  vendorId: string;
  vendorName: string;
  orderDate: string;
  expectedDeliveryDate: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
  }[];
  status: 'Ordered' | 'Partially Received' | 'Fulfilled' | 'Cancelled' | 'Awaiting Delivery';
  totalAmount: number;
}

export interface ReturnItem {
  id: string;
  type: 'Internal' | 'Purchase';
  productId: string;
  productName: string;
  quantity: number;
  date: string;
  reason: string;
  status: 'Initiated' | 'Completed';
}

export interface ApprovalConfig {
  id: string;
  level: number; // 1, 2, 3...
  name: string; // e.g. "Department Level"
  role: string;
  categoryIds: string[];
  minAmount: number;
  maxAmount: number;
}
