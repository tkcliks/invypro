import React from 'react';
import { 
  BarChart3, 
  Package, 
  Truck, 
  ChevronRight,
  Menu,
  X,
  Shield,
  History
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type NavItem = {
  id: string;
  label: string;
  icon: React.ElementType;
  roles: string[];
};

const NAV_ITEMS: NavItem[] = [
  { id: '360', label: 'StoreOps 360*', icon: Shield, roles: ['Admin', 'Store Manager', 'Supervisor'] },
  { id: 'inventory', label: 'Store & Inventory', icon: Package, roles: ['Admin', 'Store Manager'] },
  { id: 'procurement', label: 'Procurement & Vendors', icon: Truck, roles: ['Admin', 'Store Manager'] },
  { id: 'dashboard', label: 'Operational Analytics', icon: BarChart3, roles: ['Admin', 'Store Manager'] },
];

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  role: string;
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
}

export default function Sidebar({ activeTab, setActiveTab, role, isOpen, setIsOpen }: SidebarProps) {
  const filteredNav = NAV_ITEMS.filter(item => item.roles.includes(role));

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-sm" 
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={cn(
        "fixed top-0 left-0 h-full bg-surface w-70 z-50 transition-transform duration-300 lg:translate-x-0 overflow-y-auto border-r border-border",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-16 border-b border-border flex items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <div className="bg-primary w-6 h-6 rounded flex items-center justify-center font-bold text-white text-xs">
              S
            </div>
            <h1 className="text-text-main font-extrabold text-sm tracking-tight flex flex-col justify-center">
              <span className="leading-tight">SRM College</span>
              <span className="text-[10px] text-text-sub font-bold uppercase tracking-[0.2em]">fireflylabz</span>
            </h1>
          </div>
          <button className="lg:hidden text-text-sub" onClick={() => setIsOpen(false)}>
            <X size={20} />
          </button>
        </div>

        <nav className="p-6 space-y-1">
          {filteredNav.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                if (window.innerWidth < 1024) setIsOpen(false);
              }}
              className={cn(
                "sidebar-link w-full",
                activeTab === item.id && "active"
              )}
            >
              <item.icon size={18} className={cn(activeTab === item.id ? "text-primary" : "text-text-sub")} />
              <span className="text-xs font-semibold flex-1 text-left">{item.label}</span>
              {activeTab === item.id && <ChevronRight size={12} className="text-primary" />}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 w-full p-6 border-t border-border bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="bg-accent w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-sm">
              {role[0]}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-text-main text-xs font-bold truncate">{role === 'Admin' ? 'Institution Admin' : 'Staff Member'}</p>
              <p className="text-text-sub text-[10px] font-bold uppercase tracking-widest">{role}</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
