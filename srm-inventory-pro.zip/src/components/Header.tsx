import React from 'react';
import { Search, Bell, Menu, UserCircle, LogOut, Shield } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  role: string;
  setRole: (role: any) => void;
}

export default function Header({ onMenuClick, role, setRole }: HeaderProps) {
  return (
    <header className="h-16 bg-surface border-b border-border sticky top-0 z-30 px-10 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-6">
        <button 
          onClick={onMenuClick}
          className="lg:hidden p-2 hover:bg-slate-100 rounded-lg text-text-sub"
        >
          <Menu size={20} />
        </button>
        <div className="hidden md:flex items-center bg-bg rounded-[8px] px-3 py-2 w-[96px] border border-border focus-within:w-64 transition-all duration-300">
          <Search size={14} className="text-text-sub shrink-0" />
          <input 
            type="text" 
            placeholder="Search..."
            className="bg-transparent border-none focus:ring-0 text-[10px] w-full ml-2 placeholder:text-text-sub/50 font-bold uppercase tracking-wider h-4"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 bg-bg border border-border p-1 rounded-md">
          {['Admin', 'Store Manager', 'Supervisor'].map((r) => (
            <button 
              key={r}
              onClick={() => setRole(r as any)}
              className={`px-3 py-1.5 rounded text-[9px] font-bold transition-all uppercase tracking-tighter ${role === r ? 'bg-surface shadow-sm text-primary' : 'text-text-sub hover:text-text-main'}`}
            >
              {r}
            </button>
          ))}
        </div>

        <button className="p-2 hover:bg-bg rounded-full text-text-sub transition-colors relative">
          <Bell size={18} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full border-2 border-surface"></span>
        </button>

        <div className="h-6 w-px bg-border"></div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-text-main leading-tight">Alex Rivera</p>
            <p className="text-[10px] text-text-sub font-bold uppercase tracking-widest mt-0.5">SRM Campus Adyar</p>
          </div>
          <div className="h-8 w-8 rounded-full bg-slate-200 border border-border flex items-center justify-center text-text-main font-bold text-xs ring-2 ring-transparent hover:ring-primary/20 transition-all cursor-pointer">
            AR
          </div>
        </div>
      </div>
    </header>
  );
}
